# 1819-G6 
Grupo constituído por: 

●David Alves a79625

●Pedro Dourado a77973


Neste repositório estão presentes todos os trabalhos realizados ao longo do semestre na unidade curricular de Criptografia.
As resoluções dos Guiões estão presentes em:
 * [Guiao 1](Guiao1)
 
 * [Guiao 2](Guiao2)
 
 * [Guiao 3](Guiao3)
 
 * [Guiao 4](Guiao4)
 
 * [Guiao 5](Guiao5)
 
 * [Guiao 6](Guiao6)
 
 * [Guiao 7](Guiao7)

 * [Guiao 8](Guiao8)
 
 * [Guiao 9](Guiao9)





