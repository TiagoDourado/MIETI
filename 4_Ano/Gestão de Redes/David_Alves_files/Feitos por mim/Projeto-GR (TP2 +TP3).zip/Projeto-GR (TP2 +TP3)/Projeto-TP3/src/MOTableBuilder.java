import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.List;

import org.snmp4j.event.ResponseEvent;
import org.snmp4j.util.AbstractSnmpUtility;
import org.snmp4j.agent.MOAccess;
import org.snmp4j.agent.mo.DefaultMOMutableRow2PC;
import org.snmp4j.agent.mo.DefaultMOTable;
import org.snmp4j.agent.mo.MOColumn;
import org.snmp4j.agent.mo.MOMutableTableModel;
import org.snmp4j.agent.mo.MOTable;
import org.snmp4j.agent.mo.MOTableIndex;
import org.snmp4j.agent.mo.MOTableSubIndex;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.SMIConstants;
import org.snmp4j.smi.Variable;

public class MOTableBuilder{

    private MOTableSubIndex[] subIndexes = new MOTableSubIndex[] { new MOTableSubIndex(SMIConstants.SYNTAX_INTEGER) };
    private MOTableIndex indexDef = new MOTableIndex(subIndexes, false);
    private MOTableIndex indexDef2 = new MOTableIndex(subIndexes, false);

    private final List<MOColumn> columns = new ArrayList<MOColumn>();
    private final List<Variable[]> tableRows = new ArrayList<Variable[]>();
    private final List<Variable[]> tableRows2 = new ArrayList<Variable[]>();
    private int currentRow = 0;
    private int currentCol = 0;

    private OID tableRootOid;
    private OID tableRootOid2=new OID(".1.3.6.1.3.2018.2.1.1");

    private int colTypeCnt = 0;

    public DefaultMOTable ifTable;
    public MOMutableTableModel model;
    public DefaultMOTable ifTable3;
    public MOMutableTableModel model3;
    public DefaultMOTable ifTable2;
    public MOMutableTableModel model2;

    public MOTableBuilder(OID oid) {
        this.tableRootOid = oid;
    }

    public MOTableBuilder addColumnType(int syntax, MOAccess access) {
        colTypeCnt++;
        columns.add(new MOColumn(colTypeCnt, syntax, access));
        return this;
    }


    public MOTableBuilder addRowValue(Variable variable) {
        if (tableRows.size() == currentRow) {
            tableRows.add(new Variable[columns.size()]);
        }
        tableRows.get(currentRow)[currentCol] = variable;
        currentCol++;
        if (currentCol >= columns.size()) {
            currentRow++;
            currentCol = 0;
        }
        return this;

    }


    public MOTable build() {
        ifTable = new DefaultMOTable(tableRootOid, indexDef,columns.toArray(new MOColumn[0]));
        model = (MOMutableTableModel) ifTable.getModel();

        int i = 1;

        for (Variable[] variables : tableRows) {
            model.addRow(new DefaultMOMutableRow2PC(new OID(String.valueOf(i)),
                    variables));
            i++;
        }
        ifTable.setVolatile(true);
        return ifTable;
    }
    public MOTable build2() {
        ifTable2 = new DefaultMOTable(tableRootOid, indexDef,columns.toArray(new MOColumn[0]));
        model2 = (MOMutableTableModel) ifTable2.getModel();

        int i = 1;

        for (Variable[] variables : tableRows) {
            model2.addRow(new DefaultMOMutableRow2PC(new OID(String.valueOf(i)),
                    variables));
            i++;
        }
        ifTable2.setVolatile(true);
        return ifTable2;

    }

    public MOTable apagartudo(){
        int i = 1;
        model3 = (MOMutableTableModel) ifTable2.getModel();
        model3.clear();
        ifTable2.setModel(model3);
        return ifTable2;

    }


}