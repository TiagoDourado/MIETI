import java.io.*;
import java.util.Scanner;

import org.snmp4j.smi.OID;

import com.G2.SNMP.client.SNMPManager;


public class TestSNMPAgent {

    public static void main(String[] args) throws Exception {
        TestSNMPAgent client = new TestSNMPAgent("udp:127.0.0.1/161");
        client.init();

    }
    public static void ola() throws Exception {
        TestSNMPAgent client = new TestSNMPAgent("udp:127.0.0.1/161");
        client.init();

    }

    SNMPAgent agent = null;

    SNMPManager client = null;

    String address = null;

    String community;

    public TestSNMPAgent(String add) {
        address = add;
    }

    private void init() throws Exception {
        String porta = LerPorta();
        community = LerCommunity();
        String ligacao = "udp:127.0.0.1/"+porta;
        agent = new SNMPAgent(ligacao,community);
        agent.start();



        while(true) {
            Thread.sleep(20000);
        }


        //EscreverMIB();
    }

    public void parar() throws InterruptedException {
        agent.stop();
    }
    private String LerCommunity() {
        Scanner scanner=null;
        String dir;
        System.out.println("-------------------------MENU-------------------");
        System.out.println("QUAL O DIRETORIO DO FICHEIRO DE CONFIGURAÇÃO?");
        Scanner scanner1 = new Scanner(System.in);
        dir = scanner1.nextLine();

        File fp=new File(dir);
        File file=null;
        String cs = "";

        try{
            scanner=new Scanner(fp);
            cs=scanner.next();
            cs=scanner.next();
            cs=scanner.next();
            cs=scanner.next();


        }catch(FileNotFoundException e){
            System.out.println("Impossivel aceder ao ficheiro");
        }

        return cs;
    }

    public String LerPorta() throws FileNotFoundException, IOException{

        String ficheiro = "containership-conf.txt";
        File fp=new File(ficheiro);
        File file=null;
        Scanner scanner=null;
        String porta = "";

        try{
            scanner=new Scanner(fp);
            porta=scanner.next();
            porta=scanner.next();
            //System.out.println(porta);
        }catch(FileNotFoundException e){
            System.out.println("Impossivel aceder ao ficheiro");
        }



        return porta;
    }
}