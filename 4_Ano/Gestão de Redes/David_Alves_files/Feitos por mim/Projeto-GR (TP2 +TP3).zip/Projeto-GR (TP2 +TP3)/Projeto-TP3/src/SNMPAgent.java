import java.io.*;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.*;
import org.snmp4j.smi.OID;
import org.snmp4j.TransportMapping;
import org.snmp4j.agent.BaseAgent;
import org.snmp4j.agent.CommandProcessor;
import org.snmp4j.agent.DuplicateRegistrationException;
import org.snmp4j.agent.MOGroup;
import org.snmp4j.agent.ManagedObject;
import org.snmp4j.agent.mo.*;
import org.snmp4j.agent.mo.snmp.RowStatus;
import org.snmp4j.agent.mo.snmp.SnmpCommunityMIB;
import org.snmp4j.agent.mo.snmp.SnmpNotificationMIB;
import org.snmp4j.agent.mo.snmp.SnmpTargetMIB;
import org.snmp4j.agent.mo.snmp.StorageType;
import org.snmp4j.agent.mo.snmp.VacmMIB;
import org.snmp4j.agent.security.MutableVACM;
import org.snmp4j.log.Log4jLogFactory;
import org.snmp4j.log.LogFactory;
import org.snmp4j.mp.MPv3;
import org.snmp4j.security.SecurityLevel;
import org.snmp4j.security.SecurityModel;
import org.snmp4j.security.USM;
import org.snmp4j.smi.*;
import org.snmp4j.transport.TransportMappings;

import org.snmp4j.TransportMapping;
import org.snmp4j.agent.BaseAgent;
import org.snmp4j.agent.CommandProcessor;
import org.snmp4j.agent.DuplicateRegistrationException;
import org.snmp4j.agent.MOGroup;
import org.snmp4j.agent.ManagedObject;
import org.snmp4j.agent.mo.*;
import org.snmp4j.agent.mo.snmp.RowStatus;
import org.snmp4j.agent.mo.snmp.SnmpCommunityMIB;
import org.snmp4j.agent.mo.snmp.SnmpNotificationMIB;
import org.snmp4j.agent.mo.snmp.SnmpTargetMIB;
import org.snmp4j.agent.mo.snmp.StorageType;
import org.snmp4j.agent.mo.snmp.VacmMIB;
import org.snmp4j.agent.security.MutableVACM;
import org.snmp4j.log.Log4jLogFactory;
import org.snmp4j.log.LogFactory;
import org.snmp4j.mp.MPv3;
import org.snmp4j.security.SecurityLevel;
import org.snmp4j.security.SecurityModel;
import org.snmp4j.security.USM;
import org.snmp4j.smi.*;
import org.snmp4j.transport.TransportMappings;

import java.io.IOException;
import java.util.ArrayList;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SNMPAgent extends BaseAgent{

    /*static{
        LogFactory.setLogFactory(new Log4jLogFactory());
    }*/

    private String address;
    private String communitystr;
    private String dir="";
    private int nc=0;
    MOTableBuilder builder_tab3;
    long startT = System.currentTimeMillis();
    //public String s = null;
    //public final DockerClient docker = DefaultDockerClient.fromEnv().build();
    //public final List<Container> containers = docker.listContainers();
    //public final List<Container> aLLcontainers = docker.listContainers(DockerClient.ListContainersParam.allContainers());

    //Docker

    //final ContainerCreation container = docker.createContainer(ContainerConfig.builder().build());

    OID oid = new OID (".1.3.6.1.3.2018.2.1.1");

    public MOTableBuilder builder;


    int ncontainers = 0;
    int nlinhas = 0;

    MOScalar index_imagem = null;
    MOScalar nome_cont = null;
    MOScalar flag = null;

    public SNMPAgent(String address,String communitystr) throws IOException, InterruptedException {

        super(new File("conf.agent"), new File("bootCounter.agent"),
                new CommandProcessor(
                        new OctetString(MPv3.createLocalEngineID())));
        this.address = address;
        this.communitystr=communitystr;
    }
    public void criarEscalares() {

        String oid1 = ".1.3.6.1.3.2018.1.1.0";
        String oid2 = ".1.3.6.1.3.2018.1.2.0";
        String oid3 = ".1.3.6.1.3.2018.1.3.0";


        OID sysDescr1 = new OID(oid1);
        OID sysDescr2 = new OID(oid2);
        OID sysDescr3 = new OID(oid3);

        unregisterManagedObject(getSnmpv2MIB());

        index_imagem = MOCreator.createReadWriteInteger(sysDescr1,0);
        nome_cont = MOCreator.createReadWriteString(sysDescr2, "");
        flag=MOCreator.createReadWriteString(sysDescr3, "");

        registerManagedObject(index_imagem);
        registerManagedObject(nome_cont);
        registerManagedObject(flag);
    }

    public void editEscalares(String n_cont, int n_img) throws IOException {

        index_imagem.setValue(new Integer32 (n_img));
        nome_cont.setValue(new OctetString(n_cont));
        flag.setValue(new OctetString("A criar") );
        criarContainer(n_cont,n_img);
    }

    public void criarContainer(String nome, Integer nimagem) throws IOException {


        Random rand = new Random();
        //int n = rand.nextInt(50) + 50;//vai de 50 a 100
        //exec("docker stats "+nome+" --no-stream --format "+"'{{.CPUPerc}}'"+" >percent.txt");
        //String ppercentage("percent.txt");
        //String p=execret("docker stats c3 --no-stream --format {{.CPUPerc}}");
        //String p1=p.substring(0, p.length() - 1);
        //int n=Integer.valueOf(p1);
        String percent="";
        String p1="";
        int n;
        percent=Lerpercent();
        p1=percent.substring(0, percent.length() - 1);
        double d = Double.parseDouble(p1);
        n = (int) d;
        try(FileWriter fw = new FileWriter("containersTAB.txt", true);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
        {
            out.println(nome+","+nimagem+","+"up"+","+n);
            //more code
        } catch (IOException e) {
            //exception handling left as an exercise for the reader
        }
        System.out.println("A ADICIONAR CONTAINERS À TABELA DE CONTAINERS...");
        nc++;
        listar_tab3();

    }
    private String Lerpercent() {
        Scanner scanner=null;
        String dir;

        dir = "percent.txt";

        File fp=new File(dir);
        File file=null;
        String p = "";

        try{
            scanner=new Scanner(fp);
            p=scanner.next();

        }catch(FileNotFoundException e){
            System.out.println("Impossivel aceder ao ficheiro");
        }

        return p;
    }

    public void stopContainer(int indexContainer) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("containersTAB.txt"));
        String line = null;
        int lines=0;
        String[] nome= new String[100];
        int[] indimgs= new int[100];
        String[] state= new String[100];
        int[] percent= new int[100];

        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");

            for (int ii=0;ii<1;ii++) {
                nome[lines]=values[0];
                //System.out.println(nome[lines]);
                indimgs[lines]=Integer.valueOf(values[1]);
                state[lines]=values[2];
                percent[lines]=Integer.valueOf(values[3]);
            }
            lines++;
        }
        br.close();
        state[indexContainer-1]="down";

        try(FileWriter fw = new FileWriter("containersTAB.txt", false);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw))
        {
            for(int iii=0;iii<lines;iii++){
                out.println(nome[iii]+","+indimgs[iii]+","+state[iii]+","+percent[iii]);
            }
        } catch (IOException e) {
        //exception handling left as an exercise for the reader
        }
        //listar_tab3_test();
        OID interfacesTable = new OID(".1.3.6.1.3.2018.3.1.1");
        ManagedObject mo=server.getManagedObject(interfacesTable,null);
        server.unregister(mo,null);
        builder_tab3.apagartudo();
        listar_tab3();

    }

    public void removeContainer(int indexContainer) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("containersTAB.txt"));
        String line = null;
        int lines=0;
        String[] nome= new String[100];
        int[] indimgs= new int[100];
        String[] state= new String[100];
        int[] percent= new int[100];

        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");

            for (int ii=0;ii<1;ii++) {
                nome[lines]=values[0];
                //System.out.println(nome[lines]);
                indimgs[lines]=Integer.valueOf(values[1]);
                state[lines]=values[2];
                percent[lines]=Integer.valueOf(values[3]);
            }
            lines++;
        }
        br.close();
        nome[indexContainer-1]="----";
        indimgs[indexContainer-1]=0;
        state[indexContainer-1]="----";
        percent[indexContainer-1]=0;

        try(FileWriter fw = new FileWriter("containersTAB.txt", false);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
        {
            for(int iii=0;iii<lines;iii++){
                out.println(nome[iii]+","+indimgs[iii]+","+state[iii]+","+percent[iii]);
            }
        } catch (IOException e) {
            //exception handling left as an exercise for the reader
        }
        //listar_tab3_test();
        OID interfacesTable = new OID(".1.3.6.1.3.2018.3.1.1");
        ManagedObject mo=server.getManagedObject(interfacesTable,null);
        server.unregister(mo,null);
        builder_tab3.apagartudo();
        listar_tab3();

    }
    public void startContainer(int indexContainer) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("containersTAB.txt"));
        String line = null;
        int lines=0;
        String[] nome= new String[100];
        int[] indimgs= new int[100];
        String[] state= new String[100];
        int[] percent= new int[100];

        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");

            for (int ii=0;ii<1;ii++) {
                nome[lines]=values[0];
                //System.out.println(nome[lines]);
                indimgs[lines]=Integer.valueOf(values[1]);
                state[lines]=values[2];
                percent[lines]=Integer.valueOf(values[3]);
            }
            lines++;
        }
        br.close();
        state[indexContainer-1]="up";

        try(FileWriter fw = new FileWriter("containersTAB.txt", false);
            BufferedWriter bw = new BufferedWriter(fw);
            PrintWriter out = new PrintWriter(bw))
        {
            for(int iii=0;iii<lines;iii++){
                out.println(nome[iii]+","+indimgs[iii]+","+state[iii]+","+percent[iii]);
            }
        } catch (IOException e) {
            //exception handling left as an exercise for the reader
        }
        //listar_tab3_test();
        OID interfacesTable = new OID(".1.3.6.1.3.2018.3.1.1");
        ManagedObject mo=server.getManagedObject(interfacesTable,null);
        server.unregister(mo,null);
        builder_tab3.apagartudo();
        listar_tab3();

    }
    public String nomecontainer(int indexContainer) throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("containersTAB.txt"));
        String line = null;
        int lines = 0;
        String[] nome = new String[100];
        int[] indimgs = new int[100];
        String[] state = new String[100];
        int[] percent = new int[100];

        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");

            for (int ii = 0; ii < 1; ii++) {
                nome[lines] = values[0];
                //System.out.println(nome[lines]);
                indimgs[lines] = Integer.valueOf(values[1]);
                state[lines] = values[2];
                percent[lines] = Integer.valueOf(values[3]);
            }
            lines++;
        }
        br.close();
        return nome[indexContainer - 1];
    }
    @Override
    protected void addCommunities(SnmpCommunityMIB communityMIB) {
        Variable[] com2sec = new Variable[] { new OctetString(communitystr),
                new OctetString("c"+communitystr), // security name
                getAgent().getContextEngineID(), // local engine ID
                new OctetString("public"), // default context name
                new OctetString(), // transport tag
                new Integer32(StorageType.nonVolatile), // storage type
                new Integer32(RowStatus.active) // row statusIMPORTANNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNNTE
        };
        MOTableRow row = communityMIB.getSnmpCommunityEntry().createRow(
                new OctetString("public2public").toSubIndex(true), com2sec);
        communityMIB.getSnmpCommunityEntry().addRow((SnmpCommunityMIB.SnmpCommunityEntryRow) row);

    }

    @Override
    protected void addNotificationTargets(SnmpTargetMIB arg0,
                                          SnmpNotificationMIB arg1) {
        // TODO Auto-generated method stub

    }

    @Override
    protected void addUsmUser(USM arg0) {
        // TODO Auto-generated method stub

    }

    @Override
    protected void addViews(VacmMIB vacm) {
        vacm.addGroup(SecurityModel.SECURITY_MODEL_SNMPv2c, new OctetString(
                        "c"+communitystr), new OctetString("v1v2group"),
                StorageType.nonVolatile);

        vacm.addAccess(new OctetString("v1v2group"), new OctetString("public"),
                SecurityModel.SECURITY_MODEL_ANY, SecurityLevel.NOAUTH_NOPRIV,
                MutableVACM.VACM_MATCH_EXACT, new OctetString("fullReadView"),
                new OctetString("fullWriteView"), new OctetString(
                        "fullNotifyView"), StorageType.nonVolatile);

        vacm.addViewTreeFamily(new OctetString("fullReadView"), new OID(".1.3.6.1.3.2018"),
                new OctetString(), VacmMIB.vacmViewIncluded,
                StorageType.nonVolatile);

        vacm.addViewTreeFamily(new OctetString("fullWriteView"), new OID(".1.3.6.1.3.2018"),
                new OctetString(), VacmMIB.vacmViewIncluded,
                StorageType.nonVolatile);
    }

    @Override
    protected void unregisterManagedObjects() {
        // TODO Auto-generated method stub
    }

    @Override
    protected void registerManagedObjects() {
        // TODO Auto-generated method stub

    }

    protected void initTransportMappings() throws IOException {
        transportMappings = new TransportMapping[1];
        Address addr = GenericAddress.parse(address);
        TransportMapping tm = TransportMappings.getInstance()
                .createTransportMapping(addr);
        transportMappings[0] = tm;
    }

    public void lerdirimagens() throws IOException {
        System.out.println("-------------------------MENU-------------------");
        System.out.println("QUAL O DIRETORIO DO FICHEIRO DE IMAGENS?");
        Scanner scanner1 = new Scanner(System.in);
        dir = scanner1.nextLine();
        soparaoidImg(dir);
        //Lerfichimagens(dir);
    }

    public void start() throws Exception {
        lerdirimagens();
        substart();
    }
    public void substart() throws Exception {
        init();
        addShutdownHook();
        getServer().addContext(new OctetString("public"));
        finishInit();
        run();

        sendColdStartNotification();
        criarData();
        criarEscalares();
        menu();
    }

    private void listar_imagens(ArrayList <String> listaImagens) {



        OID interfacesTable = new OID(".1.3.6.1.3.2018.2.1.1");


       builder = new MOTableBuilder(interfacesTable)
                .addColumnType(SMIConstants.SYNTAX_INTEGER,MOAccessImpl.ACCESS_READ_WRITE)
                .addColumnType(SMIConstants.SYNTAX_OCTET_STRING,MOAccessImpl.ACCESS_READ_WRITE);

        for(int o = 0;o<listaImagens.size();o++) {
            builder.addRowValue(new Integer32(o+1))
                    .addRowValue(new OctetString(listaImagens.get(o)));
        }

        registerManagedObject(builder.build());

    }

    private void listar_tab3() throws IOException {
        BufferedReader br = new BufferedReader(new FileReader("containersTAB.txt"));
        String line = null;
        int lines=0;
        OID interfacesTable = new OID(".1.3.6.1.3.2018.3.1.1");
        //

        builder_tab3= new MOTableBuilder(interfacesTable)
                .addColumnType(SMIConstants.SYNTAX_INTEGER,MOAccessImpl.ACCESS_READ_ONLY)
                .addColumnType(SMIConstants.SYNTAX_OCTET_STRING,MOAccessImpl.ACCESS_READ_ONLY)
                .addColumnType(SMIConstants.SYNTAX_INTEGER,MOAccessImpl.ACCESS_READ_WRITE )
                .addColumnType(SMIConstants.SYNTAX_OCTET_STRING,MOAccessImpl.ACCESS_READ_ONLY)
                .addColumnType(SMIConstants.SYNTAX_INTEGER,MOAccessImpl.ACCESS_READ_ONLY);


        while ((line = br.readLine()) != null) {
            String[] values = line.split(",");
            lines++;
            int indexx=1;
            for (int ii=0;ii<1;ii++) {
                //OID interfacesTable1 = new OID(".1.3.6.1.3.2018.3.1.1."+indexx);
                builder_tab3.addRowValue(new Integer32(lines));
                builder_tab3.addRowValue(new OctetString(values[0]));
                builder_tab3.addRowValue(new Integer32(Integer.valueOf(values[1])));
                builder_tab3.addRowValue(new OctetString(values[2]));
                builder_tab3.addRowValue(new Integer32(Integer.valueOf(values[3])));

            }


        }
       registerManagedObject(builder_tab3.build2());





        br.close();

    }


    public void menu() throws Exception {

        //System.out.println("A ADICIONAR IMAGENS À TABELA DE IMAGENS...");
        long end = System.currentTimeMillis();
        long dif = (end/10000)-(startT/10000);
        //System.out.println(dif);
        //System.out.println("t:"+nc);
        if(dif==nc){
            System.out.println("ERRO:POR RAZÕES DE SEGURANÇA O AGENTE FOI TERMINADO");
            System.exit(1);
        }
        System.out.println("");
        System.out.println("ESCOLHA:");
        System.out.println("1-CRIAR CONTAINER");



        Scanner scanner2 = new Scanner(System.in);
        String op = scanner2.nextLine();
        String l="-l";
        if(op.equals("1")){
            System.out.println( "Qual o índice da imagem?");
            Scanner scanner3 = new Scanner(System.in);
            String imagem = scanner3.nextLine();
            int imagemInt=Integer.valueOf(imagem);
            System.out.println( "Qual nome que quer dar ao container?");
            Scanner scanner4 = new Scanner(System.in);
            String nome = scanner4.nextLine();
            Lerfichimagens(dir,imagemInt,nome);


           // System.out.println( "A criar ...");
           // System.out.println( "Container criado com sucesso.");

        }
        if(op.equals("2")){
            System.out.println( "Qual o índice do container?");
            Scanner scanner5 = new Scanner(System.in);
            String indC = scanner5.nextLine();
            stopContainer(Integer.valueOf(indC));

        }
        submenu();
    }

    private void submenu() throws Exception {
        long end = System.currentTimeMillis();
        long dif = (end/10000)-(startT/10000);
        //System.out.println(dif);
        //System.out.println("t:"+nc);
        if(dif==nc){
            System.out.println("ERRO:POR RAZÕES DE SEGURANÇA O AGENTE FOI TERMINADO");
            System.exit(1);
        }

        //stop();
        //run();
        //menu();

        System.out.println("-------");
        System.out.println("ESCOLHA:");
        System.out.println("1-CRIAR CONTAINER");
        System.out.println("2-PARAR CONTAINER");
        System.out.println("3-REMOVER CONTAINER");
        System.out.println("4-LISTAR CONTAINERS");
        System.out.println("5-RE-INICIAR CONTAINER");

        Scanner scanner2 = new Scanner(System.in);
        String op = scanner2.nextLine();
        if(op.equals("1")){
            nc++;
            OID interfacesTable = new OID(".1.3.6.1.3.2018.3.1.1");
            ManagedObject mo=server.getManagedObject(interfacesTable,null);
            server.unregister(mo,null);
            builder_tab3.apagartudo();
            System.out.println( "Qual o índice da imagem?");
            Scanner scanner3 = new Scanner(System.in);
            String imagem = scanner3.nextLine();
            int imagemInt=Integer.valueOf(imagem);
            System.out.println( "Qual nome que quer dar ao container?");
            Scanner scanner4 = new Scanner(System.in);
            String nome = scanner4.nextLine();
            Lerfichimagens(dir,imagemInt,nome);



        }
        if(op.equals("2")){

            System.out.println( "Qual o índice do container?");
            Scanner scanner5 = new Scanner(System.in);
            String indC = scanner5.nextLine();
            stopContainer(Integer.valueOf(indC));
            String container=nomecontainer(Integer.valueOf(indC));
            //
            exec("docker stop "+container);
        }

        if(op.equals("3")){
            System.out.println( "Qual o indice do container:");
            Scanner scanner3 = new Scanner(System.in);
            String cont = scanner3.nextLine();
            String cont1=nomecontainer(Integer.valueOf(cont));
            removeContainer(Integer.valueOf(cont));
            exec("docker rm "+cont1);
        }

        if(op.equals("4")){
            exec("docker ps -a");
        }
        if(op.equals("5")){
            System.out.println( "Qual o indice do container:");
            Scanner scanner3 = new Scanner(System.in);
            String cont = scanner3.nextLine();
            String cont1=nomecontainer(Integer.valueOf(cont));
            startContainer(Integer.valueOf(cont));
            exec("docker start "+cont1);
        }


        submenu();
    }

    private void exec(String cmd) throws FileNotFoundException {
        String s=null;

        try {
            Process p = Runtime.getRuntime().exec(cmd);
            //writer = new BufferedWriter( new FileWriter("percent.txt"));writer.write("ola");
            BufferedReader stdInput = new BufferedReader(new
                    InputStreamReader(p.getInputStream()));
            while ((s = stdInput.readLine()) != null) {
                System.out.println(s);
            }

            //System.exit(0);
        } catch (IOException e) {
            System.out.println("exception happened - here's what I know: ");
            e.printStackTrace();
            System.exit(-1);
        }

    }
    private void execpercent(String cmd) throws FileNotFoundException {
        String s=null;
        //BufferedWriter writer = null;
        //System.out.println("Print on console");

        // Store console print stream.
        PrintStream ps_console = System.out;

        File file = new File("percent.txt");
        FileOutputStream fos = new FileOutputStream(file);

        // Create new print stream for file.
        PrintStream ps = new PrintStream(fos);

        // Set file print stream.
        System.setOut(ps);
        //System.out.println("Print in the file !!");

        // Set console print stream.
        //System.setOut(ps_console);
        //System.out.println("Console again !!");
        try {
            Process p = Runtime.getRuntime().exec(cmd);
            //writer = new BufferedWriter( new FileWriter("percent.txt"));writer.write("ola");
            BufferedReader stdInput = new BufferedReader(new
                    InputStreamReader(p.getInputStream()));
            while ((s = stdInput.readLine()) != null) {
                System.out.println(s);
            }

            //System.exit(0);
        } catch (IOException e) {
            System.out.println("exception happened - here's what I know: ");
            e.printStackTrace();
            System.exit(-1);
        }
        System.setOut(ps_console);

        //System.out.println("Console again !!");
    }




    private void criarData() {
        Date hoje = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        System.out.println(sdf.format(hoje));
        OID stat = new OID (".1.3.6.1.3.2018.4.1.0");
        registerManagedObject(MOCreator.createReadOnlyString(stat, sdf.format(hoje)));
    }
    private <FileNotFoundException extends Throwable> void soparaoidImg(String ficheiro) throws FileNotFoundException, IOException {
        //String ficheiro = "containership-images.txt";



        File fp=new File(ficheiro);
        Scanner scanner=null;
        String img = null;
        Integer nimg = 0;
        ArrayList <String> listaImagens = new ArrayList<String>();
        int i = 0;

        try {
            scanner=new Scanner(fp);
        } catch (java.io.FileNotFoundException e) {
            e.printStackTrace();
        }
        while(scanner.hasNext()){
            img = scanner.next();
            listaImagens.add(img);
			/*while(nimg<1) {
				criarContainer(img, nimg);
				nimg++;
			}*/
        }

        listar_imagens(listaImagens);
        //criarContainer(n_cont,n_img);
    }
    private <FileNotFoundException extends Throwable> void Lerfichimagens(String ficheiro,int escolha,String nome_contador) throws FileNotFoundException, IOException {
        //String ficheiro = "containership-images.txt";



        File fp=new File(ficheiro);
        Scanner scanner=null;
        String img = null;
        Integer nimg = 0;
        ArrayList <String> listaImagens = new ArrayList<String>();
        int i = 0;

        try {
            scanner=new Scanner(fp);
        } catch (java.io.FileNotFoundException e) {
            e.printStackTrace();
        }
        while(scanner.hasNext()){
            img = scanner.next();
            listaImagens.add(img);
			/*while(nimg<1) {
				criarContainer(img, nimg);
				nimg++;
			}*/
        }
        String imgescolhida=listaImagens.get(escolha-1);
        System.out.println(listaImagens.get(escolha-1));
        exec("docker run --name "+nome_contador+" -d "+imgescolhida+" --smallfiles");
        execpercent("docker stats "+nome_contador+" --no-stream --format {{.CPUPerc}}");
        editEscalares(nome_contador,escolha);

    }
    private <FileNotFoundException extends Throwable> void sub_Lerfichimagens(String ficheiro,int escolha,String nome_contador) throws FileNotFoundException, IOException {
        //String ficheiro = "containership-images.txt";



        File fp=new File(ficheiro);
        Scanner scanner=null;
        String img = null;
        Integer nimg = 0;
        ArrayList <String> listaImagens = new ArrayList<String>();
        int i = 0;

        try {
            scanner=new Scanner(fp);
        } catch (java.io.FileNotFoundException e) {
            e.printStackTrace();
        }
        while(scanner.hasNext()){
            img = scanner.next();
            listaImagens.add(img);

        }
        //editEscalares(nome_contador,escolha);
        String imgescolhida=listaImagens.get(escolha-1);
        System.out.println(listaImagens.get(escolha-1));

        exec("docker run --name "+nome_contador+" -d "+imgescolhida+" --smallfiles");
        execpercent("docker stats "+nome_contador+" --no-stream --format {{.CPUPerc}}");

    }




    public void registerManagedObject(ManagedObject mo) {
        try {
            server.register(mo, null);

        } catch (DuplicateRegistrationException ex) {
            throw new RuntimeException(ex);
        }
    }

    public void unregisterManagedObject(MOGroup moGroup) {
        moGroup.unregisterMOs(server, getContext(moGroup));

    }
}