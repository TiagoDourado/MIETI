package agente;

import org.snmp4j.CommunityTarget;
import org.snmp4j.Snmp;
import org.snmp4j.Target;
import org.snmp4j.TransportMapping;
import org.snmp4j.smi.Address;
import org.snmp4j.smi.OID;
import org.snmp4j.smi.VariableBinding;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.DefaultPDUFactory;
import org.snmp4j.util.TreeEvent;
import org.snmp4j.util.TreeUtils;

import java.awt.*;
import java.io.IOException;
import java.util.*;
import java.util.List;

public class octetos implements Runnable {
    private String add_int;
    private Map<String, String> result = new TreeMap<String, String>();
    private CommunityTarget target;
    private int amostras=0;
    private int timer=0;
    private int contador=1;   //representa o número da amostra recolhida

    private int diferenca;
    private ArrayList<Integer> diferencas=new ArrayList<>();

    private HashMap<String,Integer> interface_tempo=new HashMap<>();


    octetos(String add_int, Map<String,String> result, CommunityTarget target,int intervalo){
        this.add_int=add_int;
        this.result=result;
        this.target=target;
        //this.amostras=n_amostras;
        this.timer=intervalo;
    }

    @Override
    public void run() {
        String oid_oct_recebidos = "1.3.6.1.2.1.2.2.1.10";
        String oid_oct_enviados = "1.3.6.1.2.1.2.2.1.16";
        String ponto = ".";
        String concate_interface_e = oid_oct_enviados + add_int;
        String concate_interface_r = oid_oct_recebidos + add_int;

        int enviados = 0;
        int recebidos = 0;
        int linhas=0; //contabiliza o número de linhas preechidas no ficheiro
        int tempo_atual=0;
        String enviado = null, recebido = null;

        //save_Data guardar=new save_Data(contador,enviados,recebidos);
        int tempo= timer*1000;

        while (contador>0) {
            try {
                result = snmpWalk("1.3.6.1.2.1.2.2", target);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {

                Thread.sleep(tempo);//seconds

            } catch (InterruptedException e) {
                e.printStackTrace();
            }


            tempo_atual=contador*timer;

            for (Map.Entry<String, String> entry : result.entrySet()) {

                if (entry.getKey().contains(concate_interface_e)) {
                    enviado=entry.getValue();
                   // System.out.println("Octetos enviados" + entry.getKey().replace(concate_interface_e, "") + ": " + entry.getValue()); //octetos
                }
                if (entry.getKey().contains(concate_interface_r)) {
                    recebido=entry.getValue();
                   // System.out.println("Octetos recebidos" + entry.getKey().replace(concate_interface_r, "") + ": " + entry.getValue()); //octetos
                }
            }
            System.out.println("");
            System.out.println("numero da amostra:"+ contador);
            System.out.println("Interface " + add_int);
            System.out.println("o timer é: "+timer);
            System.out.println(" ");

            try {
                interface_tempo.put(add_int,tempo_atual);
                int env=Integer.parseInt(enviado);
                int rec=Integer.parseInt(recebido);

                diferenca=env-rec;

                if(diferencas.size()==0){
                    diferencas.add(diferenca);
                }
                else{
                    if((diferencas.get(diferencas.size()-1))==diferenca){
                        timer=timer+1;
                        System.out.println("Novo timer da interface " +add_int+ "       é: "+timer);
                    }
                    if((diferencas.get(diferencas.size()-1))!=diferenca && timer>1){
                        timer=timer-1;
                    }
                }
                long time_atual=System.currentTimeMillis() - agenteSNMP.getStart_time();

                save_Data data=new save_Data(add_int,contador,enviado,recebido,time_atual);

            } catch (Exception e) {
                e.printStackTrace();
            }
            contador++;
        }
    }


    private static Map<String, String> snmpWalk(String tableOid, Target target) throws IOException {
        Map<String, String> result = new TreeMap<>();
        TransportMapping<? extends Address> transport = new DefaultUdpTransportMapping();
        Snmp snmp = new Snmp(transport);
        transport.listen();

        TreeUtils treeUtils = new TreeUtils(snmp, new DefaultPDUFactory());
        List<TreeEvent> events = treeUtils.getSubtree(target, new OID(tableOid));
        if (events == null || events.size() == 0) {
            System.out.println("Error: Unable to read table...");
            return result;
        }

        for (TreeEvent event : events) {
            if (event == null) {
                continue;
            }
            if (event.isError()) {
                System.out.println("Error: table OID [" + tableOid + "] " + event.getErrorMessage());
                continue;
            }

            VariableBinding[] varBindings = event.getVariableBindings();
            if (varBindings == null || varBindings.length == 0) {
                continue;
            }
            for (VariableBinding varBinding : varBindings) {
                if (varBinding == null) {
                    continue;
                }

                result.put("." + varBinding.getOid().toString(), varBinding.getVariable().toString());
            }

        }
        snmp.close();

        return result;
    }
}