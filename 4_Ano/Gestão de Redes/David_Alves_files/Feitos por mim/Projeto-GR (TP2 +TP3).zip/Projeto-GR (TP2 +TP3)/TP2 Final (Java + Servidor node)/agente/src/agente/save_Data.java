package agente;

import com.sun.jndi.toolkit.url.Uri;
import org.json.JSONObject;
import sun.misc.IOUtils;

import javax.net.ssl.HttpsURLConnection;
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


public class save_Data {
    //private static  final String ficheiro= "/home/pedro/Desktop/GR/octetos.txt";
    ArrayList<String>val_amostras=new ArrayList<>();
    int i=0;

    private Map params = new LinkedHashMap<>();
    private StringBuilder postData = new StringBuilder();

    private int diferenca;

    private String result;

    save_Data(String in,int contador, String enviado,String recebido,long tempo,String mac) throws IOException {

        int env=Integer.parseInt(enviado);
        int rec=Integer.parseInt(recebido);

        diferenca=rec-env;

        if(diferenca<0){
            diferenca=diferenca*(-1);
        }


        post(in,contador,diferenca,env,rec,tempo,mac);
        ////////////////////////////////////////////////////////////
        String ficheiro= "/home/pedro/Desktop/GR/octetos"+in+".txt";
        BufferedWriter buff = null;
        BufferedWriter buff2=null;
        FileWriter writer=new FileWriter(ficheiro,true);
        buff = new BufferedWriter(writer);

        try {
            buff.write(mac);
            buff.write("|");
            buff.write(in);
            buff.write("|");
            buff.write(Integer.toString(contador));
            buff.write("|");
            buff.write(Integer.toString(diferenca));
            buff.write("|");
            buff.write(enviado);
            buff.write("|");
            buff.write(recebido);
            buff.write("|");
            buff.write(String.valueOf(tempo));   //em milissegundos
            buff.newLine();

        } catch (IOException e) {
        } finally {
            try {
                if (buff != null)
                    buff.close();
            } catch (IOException ex){}
        }

        /////////////////////////////////////////////
    }

    public static void post(String in, int contador, int diferenca,int env,int rec, long tempo,String mac) throws IOException {
        System.out.println("endereco mac:" +mac);
        System.out.println("A diferença é:" +diferenca);


        InetAddress ip= Inet4Address.getLocalHost();
        String ip_String=ip.toString();

        String POST_PARAMS = "{\n" + "\"endereco_ip\": \""+ip_String+"\",\r\n" + "\"endereco_mac\": \""+mac+"\",\r\n" +"\"numero_amostra\":" +contador+",\r\n" +
            "    \"interfac\": \""+in+"\",\r\n" +
            "    \"diferenca_octetos\":"+diferenca+",\r\n" +
                "    \"octetos_enviados\":"+env+",\r\n" +
                "    \"octetos_recebidos\":"+rec+",\r\n" +
            "    \"tempo\": "+tempo+"" + "\n}";


        URL obj = new URL("http://ec2-34-207-88-224.compute-1.amazonaws.com:9000/octetos");
        HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
        postConnection.setRequestMethod("POST");
        postConnection.setRequestProperty("Content-Type", "application/json");

        postConnection.setDoOutput(true);
        OutputStream os = postConnection.getOutputStream();
        os.write(POST_PARAMS.getBytes());
        os.flush();
        os.close();

        int responseCode = postConnection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_CREATED) {
            BufferedReader inp = new BufferedReader(new InputStreamReader(
                    postConnection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = inp.readLine()) != null) {
                response.append(inputLine);
            } inp.close();
            System.out.println(response.toString());
        } else {
            System.out.println("POST NOT WORKED");
        }
    }
}

