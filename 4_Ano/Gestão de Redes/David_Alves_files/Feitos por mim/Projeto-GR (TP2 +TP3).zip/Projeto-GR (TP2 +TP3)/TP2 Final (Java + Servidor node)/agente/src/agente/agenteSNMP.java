package agente;

import org.snmp4j.*;
import org.snmp4j.mp.SnmpConstants;
import org.snmp4j.smi.*;
import org.snmp4j.transport.DefaultUdpTransportMapping;
import org.snmp4j.util.DefaultPDUFactory;
import org.snmp4j.util.TreeEvent;
import org.snmp4j.util.TreeUtils;

import java.util.*;
import java.io.IOException;


public class agenteSNMP {
    private static ArrayList<String> interfaces = new ArrayList<String>();
    private static long start_time;

    public static void main(String[] args) throws Exception {
        String add_int = null;
        int type;
        int n_amostras = 0;

        start_time = System.currentTimeMillis();
        ArrayList<Integer> timer = new ArrayList<>();
        CommunityTarget target = setParameters();
        Map<String, String> result = new TreeMap<String, String>();
        try {
            result = snmpWalk("1.3.6.1.2.1.2.2", target); // ifTable, mib-2 interfaces
            interfaces = imprime(result, target);
            System.out.println("");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }

        StringBuilder enviar = new StringBuilder();  //nao esta a ser usado
        for (int i = 0; i < interfaces.size(); i++) {
            if (i == 0) {
                str = interfaces.get(0);
                enviar.append(str);
                enviar.append(";");
            } else {
                enviar.append(interfaces.get(i));
                enviar.append(";");
            }
        }

        int l = 1;
        while (l == 1) {
            //n_amostras = amostras();
            timer = InputTime(interfaces);
            int tam = interfaces.size();
            int i = 0;
            for (String s : interfaces) {
                if (i < tam) {
                    //System.out.println("Interface "+s+ "Tempo="+timer.get(i));
                    Thread thread = new Thread(new octetos(s, result, target, timer.get(i)));
                    //System.out.println("O tempo é: "+timer.get(i));
                    thread.start();
                    i++;
                }
            }
            n_amostras = 0;
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println(" ");
        }
    }

    public static long getStart_time(){
        return start_time;
    }


    public static ArrayList<String> getInterfaces(){
        return interfaces;
    }

    private static String InputIp() {
        System.out.println("Digite o ip:");
        Scanner input = new Scanner(System.in);
        String ip = input.nextLine();
        return ip;
    }

    public static ArrayList<Integer> InputTime(ArrayList<String> interfaces){
        ArrayList<Integer> times=new ArrayList<>();
        for(String s : interfaces) {
            System.out.println("Digite o intervalo de tempo(em segundos) entre amostras para a interface  " +s);
            Scanner input = new Scanner(System.in);
            String tempo = input.nextLine();
            int tempo1 = Integer.parseInt(tempo);
            times.add(tempo1);
        }
        return times;
    }

    public static ArrayList<String> imprime(Map<String, String> result,CommunityTarget target) throws Exception{
        ArrayList<String> interfaces=new ArrayList<>();
        System.out.println(" ");
        for(Map.Entry<String, String> entry :result.entrySet()) {

            if (entry.getKey().contains("1.3.6.1.2.1.2.2.1.2") && (!entry.getValue().equals("0")) && (!entry.getValue().equals("0.0"))) {

                System.out.println("Interface" + entry.getKey().replace("1.3.6.1.2.1.2.2.1.2", "") + ": " + entry.getValue()); //nome interfaces
                interfaces.add(entry.getKey().replace("1.3.6.1.2.1.2.2.1.2.", ""));
            }
            if (entry.getKey().contains("1.3.6.1.2.1.2.2.1.6")) {
                System.out.println("Endereço MAC" + entry.getKey().replace(".1.3.6.1.2.1.2.2.1.6", "") + ": " + entry.getValue()); //endereço MAC
            }
        }
        /*System.out.println("Nome das interfaces");
        System.out.println(interfaces);
        System.out.println(" "); */
        return interfaces;
    }

    private static String InputPort(){
        System.out.println("Digite a porta:");
        Scanner input= new Scanner(System.in);
        String port = input.nextLine ();
        return port;
    }

    private static int amostras(){
        System.out.println("Digite o numero de amostras que pretende:");
        Scanner input =new Scanner(System.in);
        String amostra=input.nextLine();
        int amostra1=Integer.parseInt(amostra);
        return amostra1;
    }

    private static String InputInterface(){
        System.out.println("Digite a interface:");
        Scanner input= new Scanner(System.in);
        String interfacen = input.nextLine ();
        return interfacen;
    }

    private static CommunityTarget setParameters(){
        CommunityTarget target = new CommunityTarget();
        String ipAdress=InputIp();
        String port=InputPort();
        target.setCommunity(new OctetString("public"));
        target.setAddress(GenericAddress.parse(ipAdress+"/"+port)); // supply your own IP and port
        target.setRetries(2);
        target.setTimeout(1500);
        target.setVersion(SnmpConstants.version2c);
        return target;
    }

    private static Map<String, String> snmpWalk(String tableOid, Target target) throws IOException {
        Map<String, String> result = new TreeMap<>();
        TransportMapping<? extends Address> transport = new DefaultUdpTransportMapping();
        Snmp snmp = new Snmp(transport);
        transport.listen();

        TreeUtils treeUtils = new TreeUtils(snmp, new DefaultPDUFactory());
        List<TreeEvent> events = treeUtils.getSubtree(target, new OID(tableOid));
        if (events == null || events.size() == 0) {
            System.out.println("Error: Unable to read table...");
            return result;
        }

        for (TreeEvent event : events) {
            if (event == null) {
                continue;
            }
            if (event.isError()) {
                System.out.println("Error: table OID [" + tableOid + "] " + event.getErrorMessage());
                continue;
            }

            VariableBinding[] varBindings = event.getVariableBindings();
            if (varBindings == null || varBindings.length == 0) {
                continue;
            }
            for (VariableBinding varBinding : varBindings) {
                if (varBinding == null) {
                    continue;
                }

                result.put("." + varBinding.getOid().toString(), varBinding.getVariable().toString());
            }

        }
        snmp.close();
        return result;
    }
}


