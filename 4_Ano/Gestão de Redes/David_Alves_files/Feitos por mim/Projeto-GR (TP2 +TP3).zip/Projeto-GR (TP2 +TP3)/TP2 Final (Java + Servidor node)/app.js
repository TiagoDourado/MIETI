
////////////////////////////////////

const express = require("express");
const app = express();
const bodyParser = require("body-parser");
const mongoose = require("mongoose");

const octetos = require("./api/operacoes");

  mongoose.connect("mongodb+srv://user1:"+'testuser'+"@cluster0-2i6od.mongodb.net/",{
	useNewUrlParser: true,
	dbName:'dbGR'
}).then(
	res => console.log('connected'))
.catch(
	err => console.log('error connecting ' + err)
  );
  
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

app.use("/octetos", octetos);

app.use((error, req, res, next) => {
  res.status(error.status || 500);
  res.json({
    error: {
      message: error.message
    }
  });
});

module.exports = app;	
