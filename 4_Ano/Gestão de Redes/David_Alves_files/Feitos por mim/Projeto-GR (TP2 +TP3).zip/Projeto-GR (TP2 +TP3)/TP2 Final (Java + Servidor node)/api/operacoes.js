const express = require('express');
const router = express.Router();
const mongoose=require('mongoose');

const octeto=require('./octetos');

router.get('/', (req, res, next) => {
    octeto.find().exec()
    .then(docs => {
        res.status(200).json(docs);
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error:err
        });
    });
});

router.get('/:interf', (req, res, next) => {
    var int=req.params.interf;
    var diferencas=[];
    var tempos=[];

    octeto.find({interfac: int},function(err,array,next) { 
        for(var i = 0; i < array; i++) {
            diferencas[i] = araay[i].diferenca;
            tempos[i]=array[i].tempo;
        }

        res.status(200).json({
            diferenca_octetos:diferencas,
            tempo:tempos
        });
    });
}); 

router.post('/',(req,res,next)=>{
    
    const oct=new octeto({
        _id:new mongoose.Types.ObjectId(),
        endereco_ip:req.body.endereco_ip,
        endereco_mac:req.body.endereco_mac,
        numero_amostra:req.body.numero_amostra,
        interfac: req.body.interfac,
        diferenca_octetos: req.body.diferenca_octetos,
        octetos_enviados: req.body.octetos_enviados,
        octetos_recebidos: req.body.octetos_recebidos,
        tempo: req.body.tempo,
    });
    oct.save().then(result => { 
        console.log(result);
        res.status(201).json({
            message:"Post request",
            createOcteto: result
        });
    })
    .catch(err => {
        console.log(err);
        res.status(500).json({
            error:err
        }); 
    });
});

module.exports = router;


