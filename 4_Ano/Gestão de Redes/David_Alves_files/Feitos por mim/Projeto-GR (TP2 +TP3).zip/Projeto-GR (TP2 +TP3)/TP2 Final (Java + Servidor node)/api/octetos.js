const mongoose=require('mongoose');

const tabela_octetos= mongoose.Schema({
    _id:mongoose.Schema.Types.ObjectId,
    
    endereco_ip: String,
    endereco_mac: String,
    numero_amostra:Number,
    interfac: String,
    diferenca_octetos: Number,
    octetos_enviados: Number,
    octetos_recebidos: Number,
	tempo: Number
});
module.exports=mongoose.model('octeto',tabela_octetos);




